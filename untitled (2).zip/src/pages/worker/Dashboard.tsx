import React, { useState } from 'react';
import { MapPin, DollarSign, Clock, Star, Bell, Settings } from 'lucide-react';
import { useAuthStore } from '../../store';

export default function WorkerDashboard() {
  const { user } = useAuthStore();
  const [isAvailable, setIsAvailable] = useState(true);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center bg-white p-6 rounded-xl shadow-sm border border-slate-200 gap-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 text-2xl font-bold">
            {user?.name?.[0]?.toUpperCase()}
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">{user?.name}</h1>
            <p className="text-slate-500 text-sm font-medium">Verified Electrician • 4.8 Rating</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-4 w-full md:w-auto">
          <div className="flex items-center bg-slate-50 px-4 py-2 rounded-xl border border-slate-200 flex-1 md:flex-none">
            <span className="text-sm font-medium text-slate-700 mr-3">Status:</span>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" checked={isAvailable} onChange={() => setIsAvailable(!isAvailable)} />
              <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-500"></div>
              <span className={`ml-3 text-sm font-bold ${isAvailable ? 'text-green-600' : 'text-slate-500'}`}>
                {isAvailable ? 'Online' : 'Offline'}
              </span>
            </label>
          </div>
          <button className="p-2 relative bg-slate-50 rounded-full text-slate-600 hover:text-blue-600 transition-colors">
            <Bell className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-center">
          <div className="flex items-center text-slate-500 mb-2">
            <DollarSign className="w-4 h-4 mr-1" />
            <span className="text-sm font-medium">Earnings</span>
          </div>
          <span className="text-2xl font-bold text-slate-900">₹0</span>
          <span className="text-xs text-green-600 mt-1">This month</span>
        </div>
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-center">
          <div className="flex items-center text-slate-500 mb-2">
            <Clock className="w-4 h-4 mr-1" />
            <span className="text-sm font-medium">Jobs</span>
          </div>
          <span className="text-2xl font-bold text-slate-900">0</span>
          <span className="text-xs text-slate-500 mt-1">Completed</span>
        </div>
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-center">
          <div className="flex items-center text-slate-500 mb-2">
            <Star className="w-4 h-4 mr-1" />
            <span className="text-sm font-medium">Rating</span>
          </div>
          <span className="text-2xl font-bold text-slate-900">0.0</span>
          <span className="text-xs text-slate-500 mt-1">0 reviews</span>
        </div>
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-center bg-gradient-to-br from-blue-600 to-blue-700 text-white border-none cursor-pointer hover:shadow-lg hover:shadow-blue-500/30 transition-all">
          <div className="flex justify-between items-center w-full">
             <span className="font-bold text-lg">Wallet</span>
             <DollarSign className="w-5 h-5 opacity-50" />
          </div>
          <span className="text-2xl font-bold mt-2">₹0</span>
          <span className="text-xs text-blue-200 mt-1 font-medium">Available to withdraw</span>
        </div>
      </div>

      {/* New Job Requests */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
          <h2 className="text-lg font-bold text-slate-900">Active Requests</h2>
          <span className="bg-slate-100 text-slate-500 text-xs font-bold px-3 py-1 rounded-full">0 New</span>
        </div>
        <div className="p-12 text-center">
          <Clock className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 font-medium">No active job requests right now.</p>
          <p className="text-slate-400 text-sm mt-1">Make sure you are online to receive requests.</p>
        </div>
      </div>
    </div>
  );
}
