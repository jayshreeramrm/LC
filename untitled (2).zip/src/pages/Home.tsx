import React from 'react';
import { Link } from 'react-router-dom';
import { Search, HardHat, ShieldCheck, Clock, Star } from 'lucide-react';
import { useAuthStore } from '../store';

export default function Home() {
  const { isAuthenticated, user } = useAuthStore();

  return (
    <div className="flex flex-col space-y-16 pb-16">
      {/* Hero Section */}
      <section className="relative text-center py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-blue-50 to-white rounded-3xl border border-blue-100 overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-30 bg-[url('https://images.unsplash.com/photo-1541888086425-d81bb19240f5?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center"></div>
        <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-0"></div>
        <div className="relative z-10 max-w-3xl mx-auto space-y-8">
          <h1 className="text-5xl font-extrabold text-slate-900 tracking-tight sm:text-6xl">
            Find the right worker <br className="hidden sm:block" />
            <span className="text-blue-600">for your job, today.</span>
          </h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Connect with verified, highly-rated professionals for construction, maintenance, and domestic help. Fast, secure, and reliable.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            {isAuthenticated ? (
              <Link
                to={user?.role === 'worker' ? '/worker' : '/customer'}
                className="w-full sm:w-auto px-8 py-4 bg-blue-600 text-white rounded-full font-semibold text-lg hover:bg-blue-700 transition-all shadow-lg hover:shadow-blue-500/30"
              >
                Go to Dashboard
              </Link>
            ) : (
              <>
                <Link
                  to="/register?role=customer"
                  className="w-full sm:w-auto px-8 py-4 bg-blue-600 text-white rounded-full font-semibold text-lg hover:bg-blue-700 transition-all shadow-lg hover:shadow-blue-500/30"
                >
                  Hire a Worker
                </Link>
                <Link
                  to="/register?role=worker"
                  className="w-full sm:w-auto px-8 py-4 bg-white text-blue-600 border-2 border-blue-100 rounded-full font-semibold text-lg hover:border-blue-200 hover:bg-blue-50 transition-all"
                >
                  Find Jobs
                </Link>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col items-center text-center space-y-4">
          <div className="h-16 w-16 bg-blue-50 rounded-full flex items-center justify-center text-blue-600">
            <ShieldCheck className="h-8 w-8" />
          </div>
          <h3 className="text-xl font-bold text-slate-900">Verified Workers</h3>
          <p className="text-slate-600">Every worker undergoes strict KYC verification including Aadhaar and Skill checks.</p>
        </div>
        <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col items-center text-center space-y-4">
          <div className="h-16 w-16 bg-blue-50 rounded-full flex items-center justify-center text-blue-600">
            <Clock className="h-8 w-8" />
          </div>
          <h3 className="text-xl font-bold text-slate-900">Instant Booking</h3>
          <p className="text-slate-600">Find nearby workers and book them instantly or schedule for later.</p>
        </div>
        <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col items-center text-center space-y-4">
          <div className="h-16 w-16 bg-blue-50 rounded-full flex items-center justify-center text-blue-600">
            <Star className="h-8 w-8" />
          </div>
          <h3 className="text-xl font-bold text-slate-900">Transparent Pricing</h3>
          <p className="text-slate-600">Clear hourly and daily rates. Read reviews before making a decision.</p>
        </div>
      </section>
      
      {/* Popular Categories */}
      <section className="space-y-8 pt-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-slate-900">Popular Services</h2>
          <p className="text-slate-600 mt-2">Hire skilled professionals across various categories</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {['Electrician', 'Plumber', 'Carpenter', 'Mason', 'Painter', 'Housekeeping'].map((cat) => (
            <div key={cat} className="bg-white border border-slate-200 hover:border-blue-300 rounded-xl p-4 flex flex-col items-center justify-center cursor-pointer transition-colors shadow-sm hover:shadow-md h-32">
              <HardHat className="h-8 w-8 text-blue-500 mb-3" />
              <span className="font-medium text-slate-900 text-sm">{cat}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
