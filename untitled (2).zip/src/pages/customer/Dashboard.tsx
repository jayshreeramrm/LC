import React from 'react';
import { Link } from 'react-router-dom';
import { Search, MapPin, Star, History, Bell } from 'lucide-react';
import { useAuthStore } from '../../store';

export default function CustomerDashboard() {
  const { user } = useAuthStore();

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex justify-between items-center bg-white p-6 rounded-xl shadow-sm border border-slate-200">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Hello, {user?.name}</h1>
          <p className="text-slate-500 text-sm mt-1">What do you need help with today?</p>
        </div>
        <button className="p-2 relative bg-slate-50 rounded-full text-slate-600 hover:text-blue-600 transition-colors">
          <Bell className="w-6 h-6" />
          <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white"></span>
        </button>
      </div>

      {/* Quick Search Card */}
      <div className="bg-blue-600 rounded-2xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 opacity-10">
          <svg width="200" height="200" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2L2 22h20L12 2zm0 4.5l6.5 13h-13L12 6.5z" />
          </svg>
        </div>
        <div className="relative z-10 max-w-xl">
          <h2 className="text-2xl font-bold mb-4">Hire a Professional</h2>
          <Link to="/search" className="flex items-center w-full bg-white/20 hover:bg-white/30 text-white rounded-xl px-4 py-3 transition-colors backdrop-blur-sm border border-white/30">
            <Search className="w-5 h-5 mr-3" />
            <span>Search by skill, name, or category...</span>
          </Link>
        </div>
      </div>

      {/* Categories */}
      <div>
        <h3 className="text-lg font-bold text-slate-900 mb-4">Categories</h3>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4">
          {['Electrician', 'Plumber', 'Carpenter', 'Mason', 'Painter', 'Housekeeping'].map(cat => (
            <Link key={cat} to={`/search?category=${cat}`} className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 flex flex-col items-center justify-center text-center hover:border-blue-300 transition-colors cursor-pointer group">
              <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                <span className="font-bold text-sm">{cat[0]}</span>
              </div>
              <span className="text-xs font-medium text-slate-700">{cat}</span>
            </Link>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-slate-900">Recent Bookings</h3>
            <Link to="#" className="text-blue-600 text-sm font-medium hover:underline">View All</Link>
          </div>
          <div className="text-center py-8 text-slate-500">
            <History className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p>You haven't made any bookings yet.</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-slate-900">Saved Workers</h3>
            <Link to="#" className="text-blue-600 text-sm font-medium hover:underline">View All</Link>
          </div>
          <div className="text-center py-8 text-slate-500">
            <Star className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p>You haven't saved any workers yet.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
