import React, { useState, useEffect } from 'react';
import { Search, MapPin, Filter, Star, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../../lib/firebase';

export default function SearchWorkers() {
  const [searchTerm, setSearchTerm] = useState('');
  const [workers, setWorkers] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchWorkers = async () => {
      setLoading(true);
      try {
        const q = query(collection(db, 'users'), where('role', '==', 'worker'));
        const querySnapshot = await getDocs(q);
        const workersList = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setWorkers(workersList);
      } catch (err) {
        console.error("Error fetching workers", err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchWorkers();
  }, []);

  const filteredWorkers = workers.filter(w => 
    w.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    w.category?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Search Header */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 flex flex-col md:flex-row gap-4 sticky top-20 z-40">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search for skills, workers..."
            className="w-full pl-10 pr-4 py-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex-1 relative">
          <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Current Location"
            className="w-full pl-10 pr-4 py-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 text-sm"
          />
        </div>
        <button className="bg-blue-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-blue-700 transition-colors flex items-center justify-center">
          <Filter className="w-5 h-5 md:mr-2" />
          <span className="hidden md:inline">Filter</span>
        </button>
      </div>

      {/* Results */}
      <div>
        <h2 className="text-xl font-bold text-slate-900 mb-4">Nearby Professionals</h2>
        {loading ? (
          <div className="text-center py-12 text-slate-500">Loading professionals...</div>
        ) : filteredWorkers.length === 0 ? (
          <div className="text-center py-12 text-slate-500 bg-white rounded-xl border border-slate-200">
            <Search className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p>No workers found matching your search.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredWorkers.map(worker => (
              <div key={worker.id} className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition-shadow">
                <div className="p-5 flex gap-4">
                  <div className="w-16 h-16 rounded-full bg-slate-200 flex items-center justify-center text-xl font-bold text-slate-500 border-2 border-slate-100">
                    {worker.name?.[0]?.toUpperCase()}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <h3 className="font-bold text-slate-900">{worker.name}</h3>
                      <div className="flex items-center text-yellow-500 text-sm font-medium bg-yellow-50 px-2 py-0.5 rounded-full">
                        <Star className="w-3 h-3 fill-current mr-1" />
                        {worker.rating || '4.5'}
                      </div>
                    </div>
                    <p className="text-sm text-slate-500">{worker.category || 'Professional'}</p>
                    <div className="flex items-center text-xs text-slate-400 mt-2 space-x-3">
                      <span className="flex items-center"><MapPin className="w-3 h-3 mr-1" /> {worker.distance || '2.0'} km</span>
                      <span className="flex items-center font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded-md">{worker.hourlyRate ? `₹${worker.hourlyRate}/hr` : '₹500/day'}</span>
                    </div>
                  </div>
                </div>
                <div className="bg-slate-50 px-5 py-3 border-t border-slate-100 flex justify-between items-center">
                  <span className="text-xs font-medium text-green-600 flex items-center">
                    <span className="w-2 h-2 rounded-full bg-green-500 mr-2"></span>
                    Available Now
                  </span>
                  <button className="text-sm font-medium text-blue-600 hover:text-blue-800">
                    Book Now
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
