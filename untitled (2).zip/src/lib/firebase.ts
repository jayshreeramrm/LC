import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { initializeFirestore, persistentLocalCache, persistentMultipleTabManager } from 'firebase/firestore';

const firebaseConfig = {
  projectId: "gen-lang-client-0277809869",
  appId: "1:1054766825585:web:b9262626f2b5244c169bd0",
  apiKey: "AIzaSyBhaGD_uSdx1DnKBM2byi9rbOiuhRs3j9Y",
  authDomain: "gen-lang-client-0277809869.firebaseapp.com",
  storageBucket: "gen-lang-client-0277809869.firebasestorage.app",
  messagingSenderId: "1054766825585",
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = initializeFirestore(app, {
  localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
  experimentalForceLongPolling: true,
});
export const googleProvider = new GoogleAuthProvider();
