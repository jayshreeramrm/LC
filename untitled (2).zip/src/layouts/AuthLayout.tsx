import React from 'react';
import { Outlet, Link } from 'react-router-dom';
import { Briefcase } from 'lucide-react';

export default function AuthLayout() {
  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col justify-center py-12 sm:px-6 lg:px-8 font-sans text-slate-900">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <Link to="/" className="flex items-center">
            <Briefcase className="h-10 w-10 text-blue-600" />
            <span className="ml-2 text-2xl font-bold text-slate-900">LabourChowk</span>
          </Link>
        </div>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-xl sm:px-10 border border-slate-200">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
