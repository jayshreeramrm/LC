export type Role = 'customer' | 'worker' | 'contractor' | 'admin';

export interface User {
  id: string;
  email: string;
  role: Role;
  name: string;
  phone?: string;
  profilePic?: string;
  createdAt: number;
}

export interface WorkerProfile extends User {
  role: 'worker';
  category: string;
  skills: string[];
  hourlyRate: number;
  dailyWage: number;
  monthlyWage: number;
  isAvailable: boolean;
  workingRadius: number; // in km
  location?: {
    lat: number;
    lng: number;
    address: string;
  };
  rating: number;
  reviewsCount: number;
  verified: boolean;
  documents: {
    aadhaar?: string;
    pan?: string;
    certificates?: string[];
  };
}

export interface Job {
  id: string;
  customerId: string;
  workerId: string;
  status: 'pending' | 'accepted' | 'rejected' | 'in_progress' | 'completed' | 'cancelled';
  category: string;
  description: string;
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  date: number;
  amount: number;
  createdAt: number;
}
