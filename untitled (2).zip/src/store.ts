import { create } from 'zustand';
import { User } from './types';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  authReady: boolean;
  login: (user: User) => void;
  logout: () => void;
  setAuthReady: (ready: boolean) => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: false,
  authReady: false,
  login: (user) => set({ user, isAuthenticated: true }),
  logout: () => set({ user: null, isAuthenticated: false }),
  setAuthReady: (ready) => set({ authReady: ready }),
}));
