import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store';
import { auth, db } from './lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';

// Layouts
import MainLayout from './layouts/MainLayout';
import AuthLayout from './layouts/AuthLayout';

// Pages
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import CustomerDashboard from './pages/customer/Dashboard';
import WorkerDashboard from './pages/worker/Dashboard';
import SearchWorkers from './pages/customer/SearchWorkers';

const ProtectedRoute = ({ children, allowedRoles }: { children: React.ReactNode, allowedRoles?: string[] }) => {
  const { user, isAuthenticated } = useAuthStore();
  
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (allowedRoles && user && !allowedRoles.includes(user.role)) {
    return <Navigate to="/" replace />;
  }
  
  return <>{children}</>;
};

export default function App() {
  const { login, logout, setAuthReady, authReady } = useAuthStore();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const docRef = doc(db, 'users', firebaseUser.uid);
          const docSnap = await getDoc(docRef);
          
          if (docSnap.exists()) {
            login({ id: firebaseUser.uid, ...docSnap.data() } as any);
          } else {
            // New user without role yet
            login({ id: firebaseUser.uid, email: firebaseUser.email || '', role: 'customer', name: firebaseUser.displayName || '', createdAt: Date.now() });
          }
        } catch (e: any) {
          console.error("Error fetching user role", e);
          if (e.code === 'unavailable' || (e.message && e.message.includes('offline'))) {
             // Just set them as customer temporarily if offline, rather than logging them out
             login({ id: firebaseUser.uid, email: firebaseUser.email || '', role: 'customer', name: firebaseUser.displayName || '', createdAt: Date.now() });
          } else {
             // Fallback to customer anyway to not completely block the user in dev mode
             login({ id: firebaseUser.uid, email: firebaseUser.email || '', role: 'customer', name: firebaseUser.displayName || '', createdAt: Date.now() });
          }
        }
      } else {
        logout();
      }
      setAuthReady(true);
    });

    return () => unsubscribe();
  }, [login, logout, setAuthReady]);

  if (!authReady) {
    return <div className="min-h-screen flex items-center justify-center bg-[#F8FAFC]">Loading...</div>;
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route element={<MainLayout />}>
          <Route path="/" element={<Home />} />
          
          {/* Customer Routes */}
          <Route path="/customer" element={
            <ProtectedRoute allowedRoles={['customer']}>
              <CustomerDashboard />
            </ProtectedRoute>
          } />
          <Route path="/search" element={
            <ProtectedRoute allowedRoles={['customer']}>
              <SearchWorkers />
            </ProtectedRoute>
          } />

          {/* Worker Routes */}
          <Route path="/worker" element={
            <ProtectedRoute allowedRoles={['worker']}>
              <WorkerDashboard />
            </ProtectedRoute>
          } />
        </Route>

        <Route element={<AuthLayout />}>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
