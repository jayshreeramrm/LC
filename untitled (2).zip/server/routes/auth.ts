import { Router } from 'express';
import nodemailer from 'nodemailer';
import crypto from 'crypto';

const router = Router();

// In-memory store for OTPs (in production, use Redis or a database)
const otpStore = new Map<string, { otp: string, expires: number }>();

const getTransporter = () => {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) {
    throw new Error('SMTP credentials are not configured.');
  }

  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || '587'),
    secure: process.env.SMTP_PORT === '465',
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });
};

router.post('/send-otp', async (req, res) => {
  try {
    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    
    const cleanEmail = email.trim().toLowerCase();
    
    // Store OTP with 10-minute expiration
    otpStore.set(cleanEmail, {
      otp,
      expires: Date.now() + 10 * 60 * 1000
    });

    try {
      const transporter = getTransporter();
      await transporter.sendMail({
        from: `"Auth System" <${process.env.SMTP_USER}>`,
        to: email,
        subject: 'Your Login Code',
        text: `Your one-time password is: ${otp}. This code expires in 10 minutes.`,
        html: `<p>Your one-time password is: <strong>${otp}</strong></p><p>This code expires in 10 minutes.</p>`,
      });
      
      res.json({ message: 'OTP sent successfully' });
    } catch (mailError: any) {
      console.error('Nodemailer error:', mailError);
      return res.status(500).json({ 
        error: 'Failed to send email. Please check SMTP configuration.',
        details: mailError.message 
      });
    }

  } catch (error: any) {
    console.error('Send OTP error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

router.post('/verify-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;
    
    if (!email || !otp) {
      return res.status(400).json({ error: 'Email and OTP are required' });
    }

    const lowerEmail = email.trim().toLowerCase();
    const storedData = otpStore.get(lowerEmail);

    if (!storedData) {
      return res.status(400).json({ error: 'No OTP requested for this email or it has expired' });
    }

    if (Date.now() > storedData.expires) {
      otpStore.delete(lowerEmail);
      return res.status(400).json({ error: 'OTP has expired' });
    }

    if (storedData.otp !== otp) {
      return res.status(400).json({ error: 'Invalid OTP' });
    }

    // OTP is valid, remove it
    otpStore.delete(lowerEmail);

    // Return a secure mock password that the frontend can use to sign in to Firebase Auth.
    // This bridges our custom OTP system with standard Firebase Email/Password auth
    // without requiring Firebase Admin SDK credentials on the server.
    const secretHash = crypto
      .createHash('sha256')
      .update(lowerEmail + process.env.APP_URL + 'SecureOtpSalt!2026')
      .digest('hex')
      .slice(0, 16);
      
    res.json({ 
      message: 'OTP verified', 
      firebasePassword: `OtpLogin!${secretHash}`
    });

  } catch (error: any) {
    console.error('Verify OTP error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
